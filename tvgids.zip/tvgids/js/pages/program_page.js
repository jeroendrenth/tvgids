$('document').ready(function() {
  var programId = getParameterByName('id');
  var channelName = getParameterByName('channel');

  var program = new Program(programId);
  program.setInfo();

  $('h1').append(channelName);

  var output = '<h2>' + program.title + '</h2>';
  output += '<div class="times">Van ' + program.start + ' tot ' + program.end + '</div>';
  output += '<div class="synopsis"><p>' + program.synopsis + '</p></div>';

  $('#program-overview').append(output);
});

function getParameterByName(name) {
  name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
    results = regex.exec(location.search);
  return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}