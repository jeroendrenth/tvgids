(function ($) {

  $('document').ready(function () {
    var test = new Guide();
    chrome.storage.local.get({cachedChannels: []}, function (items) {
      test.getNext(items.cachedChannels);
    });
  });


})(jQuery);