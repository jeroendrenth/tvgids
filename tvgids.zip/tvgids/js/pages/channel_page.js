$('document').ready(function () {
  var id = getParameterByName('id');
  var defaultSettings = [1, 2, 3, 4, 31, 34, 36, 37, 46, 92, 460];

  chrome.storage.local.get({
    cachedChannels: [],
    defaultChannels: defaultSettings
  }, function (items) {
    var channel = items.cachedChannels[id];
    var nextChannel = {};

    $.each(items.defaultChannels, function (index, value) {
      if (value == id) {
        if ((index - 1) in items.defaultChannels) {
          previousChannelId = items.defaultChannels[index - 1];
          previousChannel = items.cachedChannels[previousChannelId];
          $('#previous').text(previousChannel.name).attr({href: 'channel.html?id=' + previousChannel.id});
        }
        else {
          $('#previous').hide();
        }

        if ((index + 1) in items.defaultChannels) {
          nextChannelId = items.defaultChannels[index + 1];
          nextChannel = items.cachedChannels[nextChannelId];
          $('#next').text(nextChannel.name).attr({href: 'channel.html?id=' + nextChannel.id});
        }
        else {
          $('#next').hide();
        }

        var img = new Image();
        img.src = '../../icons/channels/' + channel.id + '.png';
        img.onload = function(){
          img.className = 'logo';
          img.setAttribute('title', channel.name);
          $('#toolbar #logo').append(img);
        };
        img.onerror = function(){
          $('#toolbar #logo').append('<h2>' + channel.name + '</h2>');
        };
      }
    });

    var guide = new Guide();
    var programs = guide.getPrograms(id);

    $.each(programs, function (index, program) {
      var current = '';
      var startDate = new Date(program.datum_start);
      var endDate = new Date(program.datum_end);
      var currentDate = new Date();

      var startHours = (startDate.getHours() < 10 ? '0' : '') + startDate.getHours();
      var startMinutes = (startDate.getMinutes() < 10 ? '0' : '') + startDate.getMinutes();
      var endHours = (endDate.getHours() < 10 ? '0' : '') + endDate.getHours();
      var endMinutes = (endDate.getMinutes() < 10 ? '0' : '') + endDate.getMinutes();

      if (currentDate > startDate && currentDate < endDate) {
        current = 'current';
      }
      var row = (current == 'current') ? '<tr class="' + current + '">' : '<tr>';
      row += '<td id="' + program.db_id + '" class="program"><a href="#">' + program.titel + '</a></td>';
      row += '<td class="from">' + startHours + ':' + startMinutes + '</td>';
      row += '<td class="to">' + endHours + ':' + endMinutes + '</td>';
      row += '</tr>';

      $('table').append(row);
    });

    $('html, body').animate({
      scrollTop: $('.current').offset().top - 45
    }, 1000);

    $('.program').bind('click', function(event) {
      event.preventDefault();
      var synopsis = $(this).find('.synopsis');

      if (synopsis.length === 0) {
        var program = new Program($(this).attr('id'));
        program.setInfo();

        var newSynopsis = '<div class="synopsis"><p>' + program.synopsis + '</p></div>';
        $(this).append(newSynopsis);
        $(this).addClass('open');
      }
      else {

        if ($(this).hasClass('open')) {
          synopsis.hide();
          $(this).removeClass('open');
        }
        else {
          synopsis.show();
          $(this).addClass('open');
        }
      }
    });
  });



});


function getParameterByName(name) {
  name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
    results = regex.exec(location.search);
  return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
