$('document').ready(function () {
  var defaultSettings = [1, 2, 3, 4, 31, 34, 36, 37, 46, 92, 460];
  chrome.storage.local.get({
    cachedChannels: [],
    defaultChannels: defaultSettings
  }, function (items) {

    items.cachedChannels.forEach(function (channel) {
      if (channel !== null) {
        var container = $('<div class="checkbox"></div>');

        var channelId = channel.id;
        var checkbox = '<input name="channel" type="checkbox" value="' + channelId + '" />';
        var label = '<label>' + channel.name + '</label>';

        $(container).append(checkbox + label);
        $('#channels').append(container);
      }
    });

    $.each(items.defaultChannels, function (index, item) {
      $('input[value="' + item + '"]').prop('checked', true);
    });
  });

  $('#save').on('click', function () {
    save_options();
  });
});

// Saves options to chrome.storage
function save_options() {
  var checked = $(':checkbox:checked');
  var channels = [];
  $.each(checked, function (index, check) {
    channels.push($(check).val());
  });

  chrome.storage.local.set({defaultChannels: channels}, function () {
    // Update status to let user know options were saved.
    var status = document.getElementById('status');
    status.textContent = 'Options saved.';
    setTimeout(function () {
      status.textContent = '';
    }, 750);
  });
}
