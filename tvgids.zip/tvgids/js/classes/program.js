function Program(programId) {
  this.programId = programId;
  this.title = '';
  this.start = '';
  this.end = '';
  this.synopsis = '';
}

Program.prototype = {
  constructor: Program,

  setInfo: function(programId) {
    var url = 'http://www.tvgids.nl/json/lists/program.php?id=' + this.programId;
    var response = jQuery.ajax({
      url: url,
      async: false,
      dataType: 'json'
    });

    var program = $.parseJSON(response.responseText);

    this.title = program.titel;
    this.start = this.parseTime(program.btijd);
    this.end = this.parseTime(program.etijd);
    this.synopsis = program.synop;
  },

  parseTime: function(time) {
    return time.substring(0, time.length - 3);
  }

};
