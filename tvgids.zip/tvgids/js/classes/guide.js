function Guide() {
  this.baseURL = 'http://www.tvgids.nl/json/lists/';
  this.channelsPath = 'channels.php';
  this.channels = [];
}

Guide.prototype = {
  constructor: Guide,

  setChannels: function () {
    var channels = [];

    url = this.baseURL + this.channelsPath;
    var response = $.parseJSON(
      jQuery.ajax({
        url: url,
        async: false,
        dataType: 'json'
      }).responseText
    );


    $.each(response, function (index, channel) {
      var id = channel.id;
      channels[id] = channel;
    });

    chrome.storage.local.set({cachedChannels: channels});
  },

  getPrograms: function (channelId) {
    var url = 'http://www.tvgids.nl/json/lists/programs.php?channels=' + channelId + '&day=0';
    var programs = $.parseJSON(
      jQuery.ajax({
        url: url,
        async: false,
        dataType: 'json'
      }).responseText
    );

    return programs[channelId];
  },

  getNext: function (cachedChannels) {
    var defaultSettings = [1, 2, 3, 4, 31, 34, 36, 37, 46, 92, 460];
    var guide = this;

    chrome.storage.local.get({defaultChannels: defaultSettings}, function (items) {
      $.each(items.defaultChannels, function (index, item) {
        var channel = cachedChannels[item];
        channel.programs = guide.getPrograms(channel.id);

        // Convert objects to array.
        if (typeof channel.programs === 'object') {
          channel.programs = $.map(channel.programs, function(value, index) {
            return [value];
          });
        }

        var currentDate = new Date();
        $.each(channel.programs, function (index, program) {
          var startDateCurrent = new Date(program.datum_start);
          var endDateCurrent = new Date(program.datum_end);

          if (currentDate > startDateCurrent && currentDate < endDateCurrent) {
            if ('titel' in program) {
              currentProgram = program;

              var startMinutesCurrent = (startDateCurrent.getMinutes() < 10 ? '0' : '') + startDateCurrent.getMinutes();
              var endMinutesCurrent = (endDateCurrent.getMinutes() < 10 ? '0' : '') + endDateCurrent.getMinutes();

              var output = '<li id="' + channel.id + '">';
              output += '<div class="current-program">';
              output += '<div><span>Nu:</span> <br />';
              output += '<a href="program.html?id=' + currentProgram.db_id + '&channel=' + channel.name + '" class="icon-info-circled">';
              output += currentProgram.titel;
              output += '</a></div>';
              output += startDateCurrent.getHours() + ':' + startMinutesCurrent;
              output += ' -  ';
              output += endDateCurrent.getHours() + ':' + endMinutesCurrent;
              output += '</div>';

              if (typeof channel.programs[index + 1] != 'undefined') {
                var nextProgram = channel.programs[index + 1];
                var startDateNext = new Date(nextProgram.datum_start);
                var endDateNext = new Date(nextProgram.datum_end);

                var startMinutesNext = (startDateNext.getMinutes() < 10 ? '0' : '') + startDateNext.getMinutes();
                var endMinutesNext = (endDateNext.getMinutes() < 10 ? '0' : '') + endDateNext.getMinutes();


                output += '<div class="next-program">';
                output += '<div><span>Straks:</span> <br />';
                output += '<a href="program.html?id=' + nextProgram.db_id + '&channel=' + channel.name + '" class="icon-info-circled">';
                output += nextProgram.titel;
                output += '</a></div>';
                output += startDateNext.getHours() + ':' + startMinutesNext;
                output += ' -  ';
                output += endDateNext.getHours() + ':' + endMinutesNext;
                output += '</div>';
              }
              output += '</li>';

              $('.jcarousel ul').append(output);
              var link = document.createElement('a');
              link.setAttribute('href', '../channel.html?id=' + channel.id);

              var img = new Image();
              img.src = '../../icons/channels/' + channel.id + '.png';
              img.onload = function(){
                img.className = 'logo';
                img.setAttribute('title', channel.name);
                $(link).append(img);
                $('li#' + channel.id).prepend(link);
              };
              img.onerror = function(){
                $(link).append('<h2>' + channel.name + '</h2>');
                $('li#' + channel.id).prepend(link);
              };

            }
            return false;
          }
        });
      });

      $('#progress-bar').hide();
      $('.jcarousel-wrapper').show();
      $('.jcarousel').jcarousel();

      $('.jcarousel-control-prev')
        .on('jcarouselcontrol:active', function () {
          $(this).removeClass('inactive');
        })
        .on('jcarouselcontrol:inactive', function () {
          $(this).addClass('inactive');
        })
        .jcarouselControl({
          target: '-=3'
        });

      $('.jcarousel-control-next')
        .on('jcarouselcontrol:active', function () {
          $(this).removeClass('inactive');
        })
        .on('jcarouselcontrol:inactive', function () {
          $(this).addClass('inactive');
        })
        .jcarouselControl({
          target: '+=3'
        });
    });
  }
};

function UrlExists(url) {
  var http = new XMLHttpRequest();
  http.open('HEAD', url, false);
  http.send();
  return http.status!=404;
}