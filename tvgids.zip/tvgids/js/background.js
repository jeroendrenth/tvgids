var guide = new Guide();
guide.setChannels();