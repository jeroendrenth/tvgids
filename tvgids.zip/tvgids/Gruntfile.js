module.exports = function(grunt) {
  var mozjpeg = require('imagemin-mozjpeg');
  grunt.initConfig({
    cssmin: {
      target: {
        files: [{
          expand: true,
          cwd: 'css',
          src: '*.css',
          dest: 'tvgids/css',
          ext: '.min.css'
        }]
      }
    },
    imagemin: {                          // Task
      dynamic: {                          // Target
        options: {                       // Target options
          optimizationLevel: 3,
          svgoPlugins: [{removeViewBox: false}],
          use: [mozjpeg()]
        },
        files: [{
          expand: true,                  // Enable dynamic expansion
          cwd: 'icons/channels/',                   // Src matches are relative to this path
          src: ['*.{png,jpg,gif}'],   // Actual patterns to match
          dest: 'tvgids/icons/channels/'                  // Destination path prefix
        }]
      }
    },
    image_resize: {
      resize: {
        options: {
          height: 50
        },
        src: 'tvgids/icons/channels/*.png',
        dest: 'tvgids/icons/channels/'
      }
    },
    uglify: {
      my_target: {
        files: [{
          expand: true,
          cwd: 'js',
          src: '*.js',
          dest: 'tvgids/js',
          ext: '.min.js'
        },
          {
            expand: true,
            cwd: 'js/pages',
            src: '*.js',
            dest: 'tvgids/js/pages',
            ext: '.min.js'
          },
          {
            expand: true,
            cwd: 'js/classes',
            src: '*.js',
            dest: 'tvgids/js/classes',
            ext: '.min.js'
          }]
      }
    },
    watch: {
      css: {
        files: ['css/*.css', 'js/*.js', 'js/classes/*.js', 'js/pages/*.js'],
        tasks: ['default'],
        options: {
          // Start a live reload server on the default port 35729
          livereload: true
        }
      }
    }
  });

  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-imagemin');
  grunt.loadNpmTasks('grunt-image-resize');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-watch');

  grunt.registerTask('default', ['uglify', 'cssmin']);


};